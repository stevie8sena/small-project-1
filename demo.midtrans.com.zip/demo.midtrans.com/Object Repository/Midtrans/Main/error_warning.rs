<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>error_warning</name>
   <tag></tag>
   <elementGuidId>b66a24d1-b4e9-4931-9915-5d80731c9f36</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[.='Sorry, something went wrong.']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[.='Sorry, something went wrong.']</value>
   </webElementProperties>
</WebElementEntity>
