<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_paynow</name>
   <tag></tag>
   <elementGuidId>1ea8e564-cf44-4484-a949-7578ace27427</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div[3]/div/div[1]/a[count(. | //*[@ref_element = 'Object Repository/Midtrans/iFrame/iframe_main']) = count(//*[@ref_element = 'Object Repository/Midtrans/iFrame/iframe_main'])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[3]/div/div[1]/a</value>
   </webElementProperties>
</WebElementEntity>
